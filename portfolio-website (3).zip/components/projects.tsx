"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { ExternalLink, Github, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const projectsData = [
  {
    title: "Network Forensics Tool",
    description: "A machine learning-based tool for network traffic analysis and anomaly detection",
    image: "/placeholder.svg?height=300&width=500",
    tags: ["Python", "TensorFlow", "Network Security"],
    demoLink: "#",
    repoLink: "#",
  },
  {
    title: "Smart Home Dashboard",
    description: "Web interface for monitoring and controlling IoT devices in a smart home environment",
    image: "/placeholder.svg?height=300&width=500",
    tags: ["React", "Node.js", "IoT"],
    demoLink: "#",
    repoLink: "#",
  },
  {
    title: "Network Monitoring System",
    description: "Real-time monitoring system for enterprise networks with alert capabilities",
    image: "/placeholder.svg?height=300&width=500",
    tags: ["JavaScript", "Express", "MongoDB"],
    demoLink: "#",
    repoLink: "#",
  },
]

export default function Projects() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <section id="projects" className="py-20 bg-white dark:bg-gray-950">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="section-heading">
            <span className="text-gradient">Proyek Unggulan</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projectsData.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="overflow-hidden h-full border-lightblue-100 dark:border-gray-800 hover:shadow-md transition-all duration-300">
                  <div className="relative overflow-hidden aspect-video">
                    <img
                      src={project.image || "/placeholder.svg"}
                      alt={project.title}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                      width={500}
                      height={300}
                    />
                  </div>
                  <CardHeader>
                    <CardTitle className="text-xl">{project.title}</CardTitle>
                    <CardDescription>{project.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {project.tags.map((tag, tagIndex) => (
                        <Badge
                          key={tagIndex}
                          variant="secondary"
                          className="bg-lightblue-100 text-lightblue-800 dark:bg-lightblue-900/30 dark:text-lightblue-300"
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm" className="border-lightblue-200 dark:border-gray-700" asChild>
                      <a href={project.repoLink} target="_blank" rel="noopener noreferrer">
                        <Github className="mr-2 h-4 w-4" />
                        Code
                      </a>
                    </Button>
                    <Button size="sm" className="bg-lightblue-500 hover:bg-lightblue-600 text-white" asChild>
                      <a href={project.demoLink} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="mr-2 h-4 w-4" />
                        Demo
                      </a>
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Button
              variant="outline"
              className="border-lightblue-300 dark:border-lightblue-700 hover:bg-lightblue-50 dark:hover:bg-gray-800 rounded-full px-6"
            >
              Lihat Semua Proyek
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
