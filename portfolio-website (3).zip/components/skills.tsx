"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Network, Code, Database, Cpu, PenTool, LineChart } from "lucide-react"

const skillsData = [
  {
    category: "Jaringan Komputer",
    description: "Pengalaman praktikal di PT. ARTHAGUNA dan Telkom Indonesia",
    icon: <Network className="w-10 h-10" />,
  },
  {
    category: "UI/UX",
    description: "Desain antarmuka dan pengalaman pengguna untuk aplikasi web modern",
    icon: <PenTool className="w-10 h-10" />,
  },
  {
    category: "Programming",
    description: "Web Programming dengan fokus pada pengembangan aplikasi modern",
    icon: <Code className="w-10 h-10" />,
  },
  {
    category: "Database Management",
    description: "Pengelolaan dan optimasi database untuk aplikasi",
    icon: <Database className="w-10 h-10" />,
  },
  {
    category: "Network Engineering",
    description: "Implementasi dan troubleshooting jaringan komputer",
    icon: <Cpu className="w-10 h-10" />,
  },
  {
    category: "Machine Learning",
    description: "Pemanfaatan Algoritma Machine Learning untuk Investigasi Network Forensics",
    icon: <LineChart className="w-10 h-10" />,
  },
]

export default function Skills() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <section id="skills" className="py-20 bg-lightblue-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="section-heading">
            <span className="text-gradient">Keahlian Saya</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skillsData.map((skill, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="skill-card group"
              >
                <div className="mb-4 text-lightblue-500 dark:text-lightblue-400 group-hover:scale-110 transition-transform duration-300">
                  {skill.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">{skill.category}</h3>
                <p className="text-gray-600 dark:text-gray-400">{skill.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
