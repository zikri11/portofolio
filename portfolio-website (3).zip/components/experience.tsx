"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Briefcase, Calendar, MapPin } from "lucide-react"

const experienceData = [
  {
    position: "Technician",
    company: "PT. ARTHAGUNA",
    type: "Magang",
    period: "Mei 2023 - Juli 2023 (3 bulan)",
    location: "Cigalontang, Jawa Barat, Indonesia",
    skills: ["Jaringan Komputer"],
    description: "Melakukan instalasi dan konfigurasi jaringan komputer, serta troubleshooting masalah jaringan.",
    icon: <Briefcase className="w-6 h-6" />,
  },
  {
    position: "Technician",
    company: "Telkom Indonesia",
    type: "Magang",
    period: "Juli 2022 - Oktober 2022 (4 bulan)",
    location: "Tasikmalaya, Jawa Barat, Indonesia",
    skills: ["Network Engineering", "Jaringan Komputer"],
    description:
      "Membantu dalam implementasi dan pemeliharaan infrastruktur jaringan, serta memberikan dukungan teknis.",
    icon: <Briefcase className="w-6 h-6" />,
  },
]

export default function Experience() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <section id="experience" className="py-20 bg-lightblue-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mx-auto"
        >
          <h2 className="section-heading">
            <span className="text-gradient">Pengalaman Kerja</span>
          </h2>

          <div className="space-y-12">
            {experienceData.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className="timeline-item"
              >
                <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-lightblue-100 dark:border-gray-700">
                  <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-4">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                      {item.position} |{" "}
                      <span className="text-lightblue-600 dark:text-lightblue-400">{item.company}</span>
                    </h3>
                    <span className="text-sm text-gray-600 dark:text-gray-400 mt-1 md:mt-0 px-3 py-1 rounded-full bg-lightblue-50 dark:bg-lightblue-900/20">
                      {item.type}
                    </span>
                  </div>

                  <div className="flex items-center text-gray-600 dark:text-gray-400 mb-2">
                    <Calendar className="w-4 h-4 mr-2 text-lightblue-500 dark:text-lightblue-400" />
                    <span className="text-sm">{item.period}</span>
                  </div>

                  <div className="flex items-center text-gray-600 dark:text-gray-400 mb-4">
                    <MapPin className="w-4 h-4 mr-2 text-lightblue-500 dark:text-lightblue-400" />
                    <span className="text-sm">{item.location}</span>
                  </div>

                  <p className="text-gray-700 dark:text-gray-300 mb-4">{item.description}</p>

                  <div className="flex flex-wrap gap-2">
                    {item.skills.map((skill, skillIndex) => (
                      <span
                        key={skillIndex}
                        className="px-3 py-1 bg-lightblue-100 dark:bg-lightblue-900/30 text-lightblue-800 dark:text-lightblue-300 rounded-full text-xs font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
