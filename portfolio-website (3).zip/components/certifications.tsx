"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Award, Calendar, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"

const certificationsData = [
  {
    title: "Pemanfaatan Algoritma Machine Learning untuk Investigasi Network Forensics",
    issuer: "Badan Kejuruan Informatika Persatuan Insinyur Indonesia",
    date: "Februari 2025",
    icon: <Award className="w-6 h-6" />,
  },
  {
    title: "Web Programming",
    issuer: "Himpunan Informatika Universitas Siliwangi",
    date: "Juni 2024",
    icon: <Award className="w-6 h-6" />,
  },
  {
    title: "Kompetensi Teknik Komputer Jaringan",
    issuer: "Urban Access",
    date: "Agustus 2023",
    icon: <Award className="w-6 h-6" />,
  },
]

export default function Certifications() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <section id="certifications" className="py-20 bg-lightblue-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mx-auto"
        >
          <h2 className="section-heading">
            <span className="text-gradient">Sertifikasi</span>
          </h2>

          <div className="grid grid-cols-1 gap-6">
            {certificationsData.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-lightblue-100 dark:border-gray-700 hover:shadow-md transition-all duration-300"
              >
                <div className="flex items-start">
                  <div className="w-12 h-12 rounded-full bg-lightblue-100 dark:bg-lightblue-900/30 flex items-center justify-center mr-4 text-lightblue-600 dark:text-lightblue-400 flex-shrink-0">
                    {item.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">{item.title}</h3>
                    <p className="text-gray-700 dark:text-gray-300 mb-2">{item.issuer}</p>
                    <div className="flex items-center text-gray-600 dark:text-gray-400">
                      <Calendar className="w-4 h-4 mr-2 text-lightblue-500 dark:text-lightblue-400" />
                      <span className="text-sm">{item.date}</span>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="text-lightblue-600 dark:text-lightblue-400">
                    <ExternalLink className="h-5 w-5" />
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
