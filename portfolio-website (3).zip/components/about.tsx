"use client"

import { motion } from "framer-motion"
import { MapPin, Mail, Phone, ExternalLink } from "lucide-react"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"

export default function About() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-950">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="section-heading">
            <span className="text-gradient">Tentang Saya</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-center">
            <div className="md:col-span-5">
              <div className="relative">
                <div className="absolute -inset-4 bg-lightblue-100 dark:bg-lightblue-900/30 rounded-2xl -rotate-6"></div>
                <div className="absolute -inset-4 bg-lightblue-50 dark:bg-lightblue-900/10 rounded-2xl rotate-3"></div>
                <div className="relative rounded-2xl overflow-hidden shadow-xl">
                  <img
                    src="/placeholder.svg?height=600&width=450"
                    alt="Muhammad Zikri Agustian"
                    className="object-cover w-full aspect-[3/4]"
                    width={450}
                    height={600}
                    loading="lazy"
                  />
                </div>
              </div>
            </div>

            <div className="md:col-span-7">
              <div className="space-y-6">
                <div className="flex items-center space-x-2 text-lightblue-600 dark:text-lightblue-400">
                  <MapPin className="w-5 h-5" />
                  <p>Bandung, Jawa Barat, Indonesia</p>
                </div>

                <h3 className="text-2xl font-bold">Network Engineer & Web Developer</h3>

                <p className="text-gray-700 dark:text-gray-300">
                  Saya adalah Network Engineer dan Web Developer yang bersemangat dengan keahlian dalam aplikasi Machine
                  Learning untuk Network Forensics. Perjalanan profesional saya mencakup pengalaman praktis di PT.
                  ARTHAGUNA dan Telkom Indonesia, di mana saya mengasah keterampilan dalam rekayasa jaringan dan sistem
                  komputer.
                </p>

                <p className="text-gray-700 dark:text-gray-300">
                  Dengan latar belakang pendidikan yang kuat dari Universitas Siliwangi, saya telah mengembangkan
                  kompetensi dalam Pemrograman Web dan Teknologi Jaringan Komputer. Saya sangat tertarik pada perpaduan
                  keamanan jaringan, pengembangan web, dan aplikasi machine learning.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-10 h-10 rounded-full bg-lightblue-100 dark:bg-lightblue-900/30 flex items-center justify-center text-lightblue-600 dark:text-lightblue-400">
                      <Mail className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Email</p>
                      <p className="font-medium">contact@muhammadzikri.com</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-10 h-10 rounded-full bg-lightblue-100 dark:bg-lightblue-900/30 flex items-center justify-center text-lightblue-600 dark:text-lightblue-400">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Telepon</p>
                      <p className="font-medium">+62 812 3456 7890</p>
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    className="bg-lightblue-500 hover:bg-lightblue-600 text-white rounded-full px-6"
                    onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
                  >
                    Hubungi Saya
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
