"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Mail, Phone, MapPin, Send, Github, Linkedin, Twitter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

export default function Contact() {
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      toast({
        title: "Message sent!",
        description: "Thank you for your message. I'll get back to you soon.",
      })
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: "",
      })
      setIsSubmitting(false)
    }, 1500)
  }

  return (
    <section id="contact" className="py-20 bg-lightblue-50 dark:bg-gray-900 relative overflow-hidden">
      {/* Background blobs */}
      <div className="blob blob-blue w-96 h-96 -bottom-48 -right-48"></div>
      <div className="blob blob-cyan w-64 h-64 top-20 left-20"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="section-heading">
            <span className="text-gradient">Hubungi Saya</span>
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            <div className="lg:col-span-5">
              <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-sm border border-lightblue-100 dark:border-gray-700 h-full">
                <h3 className="text-2xl font-semibold mb-6 text-gray-900 dark:text-white">Informasi Kontak</h3>

                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="w-12 h-12 rounded-full bg-lightblue-100 dark:bg-lightblue-900/30 flex items-center justify-center mr-4 text-lightblue-600 dark:text-lightblue-400">
                      <Mail className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-base font-medium text-gray-900 dark:text-white mb-1">Email</h4>
                      <p className="text-gray-600 dark:text-gray-400">contact@muhammadzikri.com</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="w-12 h-12 rounded-full bg-lightblue-100 dark:bg-lightblue-900/30 flex items-center justify-center mr-4 text-lightblue-600 dark:text-lightblue-400">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-base font-medium text-gray-900 dark:text-white mb-1">Phone</h4>
                      <p className="text-gray-600 dark:text-gray-400">+62 812 3456 7890</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="w-12 h-12 rounded-full bg-lightblue-100 dark:bg-lightblue-900/30 flex items-center justify-center mr-4 text-lightblue-600 dark:text-lightblue-400">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-base font-medium text-gray-900 dark:text-white mb-1">Location</h4>
                      <p className="text-gray-600 dark:text-gray-400">Bandung, Jawa Barat, Indonesia</p>
                    </div>
                  </div>
                </div>

                <div className="mt-10">
                  <h4 className="text-base font-medium text-gray-900 dark:text-white mb-4">Follow Me</h4>
                  <div className="flex space-x-4">
                    <a
                      href="https://github.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full bg-lightblue-100 dark:bg-lightblue-900/30 hover:bg-lightblue-200 dark:hover:bg-lightblue-900/50 flex items-center justify-center text-lightblue-600 dark:text-lightblue-400 transition-colors duration-300"
                      aria-label="GitHub"
                    >
                      <Github className="w-5 h-5" />
                    </a>
                    <a
                      href="https://linkedin.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full bg-lightblue-100 dark:bg-lightblue-900/30 hover:bg-lightblue-200 dark:hover:bg-lightblue-900/50 flex items-center justify-center text-lightblue-600 dark:text-lightblue-400 transition-colors duration-300"
                      aria-label="LinkedIn"
                    >
                      <Linkedin className="w-5 h-5" />
                    </a>
                    <a
                      href="https://twitter.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full bg-lightblue-100 dark:bg-lightblue-900/30 hover:bg-lightblue-200 dark:hover:bg-lightblue-900/50 flex items-center justify-center text-lightblue-600 dark:text-lightblue-400 transition-colors duration-300"
                      aria-label="Twitter"
                    >
                      <Twitter className="w-5 h-5" />
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7">
              <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-sm border border-lightblue-100 dark:border-gray-700">
                <h3 className="text-2xl font-semibold mb-6 text-gray-900 dark:text-white">Kirim Pesan</h3>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Nama Anda
                      </label>
                      <Input
                        id="name"
                        type="text"
                        name="name"
                        placeholder="John Doe"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="bg-white dark:bg-gray-900 border-lightblue-200 dark:border-gray-700 focus:border-lightblue-500 dark:focus:border-lightblue-400"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="email"
                        className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                      >
                        Email Anda
                      </label>
                      <Input
                        id="email"
                        type="email"
                        name="email"
                        placeholder="john@example.com"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="bg-white dark:bg-gray-900 border-lightblue-200 dark:border-gray-700 focus:border-lightblue-500 dark:focus:border-lightblue-400"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="subject"
                      className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                    >
                      Subjek
                    </label>
                    <Input
                      id="subject"
                      type="text"
                      name="subject"
                      placeholder="Bagaimana saya dapat membantu Anda?"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                      className="bg-white dark:bg-gray-900 border-lightblue-200 dark:border-gray-700 focus:border-lightblue-500 dark:focus:border-lightblue-400"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="message"
                      className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                    >
                      Pesan
                    </label>
                    <Textarea
                      id="message"
                      name="message"
                      placeholder="Pesan Anda di sini..."
                      value={formData.message}
                      onChange={handleChange}
                      required
                      className="min-h-[150px] bg-white dark:bg-gray-900 border-lightblue-200 dark:border-gray-700 focus:border-lightblue-500 dark:focus:border-lightblue-400"
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-lightblue-500 hover:bg-lightblue-600 text-white rounded-lg py-3"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center">
                        <svg
                          className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                        >
                          <circle
                            className="opacity-25"
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="4"
                          ></circle>
                          <path
                            className="opacity-75"
                            fill="currentColor"
                            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                          ></path>
                        </svg>
                        Mengirim...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <Send className="w-4 h-4 mr-2" />
                        Kirim Pesan
                      </span>
                    )}
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
