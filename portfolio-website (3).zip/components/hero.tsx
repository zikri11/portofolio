"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { ChevronDown, ArrowRight, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { TypeAnimation } from "react-type-animation"

export default function Hero() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background blobs */}
      <div className="blob blob-blue w-96 h-96 -top-20 -left-20"></div>
      <div className="blob blob-cyan w-96 h-96 bottom-20 right-20"></div>
      <div className="blob blob-sky w-64 h-64 top-1/3 right-1/4"></div>

      <div className="container mx-auto px-4 z-10 py-20">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 text-center md:text-left mb-12 md:mb-0">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
                <span className="inline-block">
                  Halo! <span className="inline-block animate-wave origin-bottom-right">👋</span>
                </span>
                <br />
                Saya <span className="text-gradient">Muhammad Zikri</span>
              </h1>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mb-8"
            >
              <div className="text-xl md:text-2xl text-gray-700 dark:text-gray-300 h-16">
                <TypeAnimation
                  sequence={["Network Engineer", 2000, "Web Developer", 2000, "Machine Learning Enthusiast", 2000]}
                  wrapper="span"
                  speed={50}
                  repeat={Number.POSITIVE_INFINITY}
                />
              </div>
              <p className="text-gray-600 dark:text-gray-400 mt-4 max-w-lg">
                Bersemangat dalam membangun jaringan yang kuat dan menciptakan solusi web inovatif dengan fokus pada
                keamanan dan kinerja.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="flex flex-wrap justify-center md:justify-start gap-4"
            >
              <Button
                size="lg"
                className="bg-lightblue-500 hover:bg-lightblue-600 text-white dark:bg-lightblue-600 dark:hover:bg-lightblue-700 rounded-full px-6"
                onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
              >
                Hubungi Saya
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-lightblue-300 dark:border-lightblue-700 hover:bg-lightblue-50 dark:hover:bg-gray-800 rounded-full px-6"
              >
                Unduh CV
                <Download className="ml-2 h-4 w-4" />
              </Button>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="w-full md:w-1/2 flex justify-center md:justify-end"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-lightblue-500 rounded-full blur-3xl opacity-20 animate-pulse"></div>
              <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-white dark:border-gray-800 shadow-xl">
                <img
                  src="/placeholder.svg?height=320&width=320"
                  alt="Muhammad Zikri Agustian"
                  className="object-cover w-full h-full"
                  width={320}
                  height={320}
                />
              </div>
              {/* Jam SVG telah dihapus sesuai permintaan */}
            </div>
          </motion.div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 cursor-pointer"
        onClick={() => document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })}
      >
        <ChevronDown className={cn("w-8 h-8 text-lightblue-500 dark:text-lightblue-400 animate-bounce")} />
      </motion.div>
    </section>
  )
}
